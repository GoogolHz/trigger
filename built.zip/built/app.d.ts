/*!
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
import * as MRE from '@microsoft/mixed-reality-extension-sdk';
/**
 * The main class of this app. All the logic goes here.
 */
export default class Grabbable {
    private context;
    private params;
    private baseUrl;
    private syncfix;
    private attachments;
    private prefabs;
    private text;
    private kitItemStylus;
    private userTrackers;
    private assets;
    private artifactDB;
    private contentPack;
    private videoWand;
    private fractalTransA;
    private fractalTransB;
    private fractalTransC;
    PI: number;
    TAU: number;
    /**
     * From GrabTest Functional test
     *
     */
    private readonly SCALE;
    cleanup(): void;
    constructor(context: MRE.Context, params: MRE.ParameterSet, baseUrl: string);
    private synchronizeAttachments;
    /**
     * Once the context is "started", initialize the app.
     */
    private started;
    private startedImpl;
    /**
     * Preload all hat resources. This makes instantiating them faster and more efficient.
     */
    private preloadArtifacts;
    private loadArtifacts;
    private userJoined;
    private userLeft;
}
//# sourceMappingURL=app.d.ts.map